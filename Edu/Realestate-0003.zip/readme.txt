=============================================================================
// BUSINESS CARD JOURNAL - FREE PREMIUM BUSINESS CARD DESIGNS ///////////////
=============================================================================

Free professionally designed business card templates from
businesscardjournal.com

We highly recommend more free templates from our network

// free-business-card-templates.com
// igraphiclogo.com


=============================================================================
// SOCIAL MEDIA - FOLLOW US /////////////////////////////////////////////////
=============================================================================

Facebook - https://www.facebook.com/BusinessCardJournal
Twitter - https://twitter.com/bizcardjournal
Google+ - https://plus.google.com/104751866359714050180/
Pinterest - http://pinterest.com/bizcardjournal/free-business-card-templates/
Flickr - http://www.flickr.com/photos/mengloong/


=============================================================================
// LICENSE //////////////////////////////////////////////////////////////////
=============================================================================

This business card template are free for both commercial and
personal use unless stated. You cannot distribute, lease,
license, sell and upload to any file sharing network or
website without a prior written permission from
businesscardjournal.com

Online use is phohibited - Contact us if in doubt
-----------------------------------------------------------------------------
You CANNOT use any templates from businesscardjournal.com
for any online usage including but not limited to
- selling, redistributing the template as whole, modified or not.
- displaying on your website as part of your print template inventory.
  You can link to our template download page but not the file directly.
- using our templates to create and sell business card design at jobsites
  i.e. 99designs.com, fiverr.com and other related websites.
- Freebies website must direct users to our download page instead of
  hosting our templates at your website or other file hosting website.
  Never link to our file directly from your website.

It's best to contact us before using our templates for any online activity.
We will most likely decline although it's worth a try.

http://businesscardjournal.com/contact/


=============================================================================
// FONTS ////////////////////////////////////////////////////////////////////
=============================================================================

Download free fonts used in this template

1) Open Sans - http://www.fontsquirrel.com/fonts/open-sans

